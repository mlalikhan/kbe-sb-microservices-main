package guru.sfg.brewery.inventory_service.config;

/**
 * Created by jt on 2019-05-31.
 */
//@EnableIntegration
//@IntegrationComponentScan
//@Configuration
public class SiConfiguration {

//    @Bean(name = PollerMetadata.DEFAULT_POLLER)
//    public PollerMetadata poller() {
//        return Pollers.fixedRate(500).get();
//    }
    //@Bean
    //public MessageSource<String> newInventory(){
//        org.springframework.integration.core.MessageSource
    //}

}
