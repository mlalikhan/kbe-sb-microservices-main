package guru.sfg.brewery.beer_service.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * Created by jt on 2019-06-09.
 */
@EnableCaching
@Configuration
public class CacheConfig {
}
