package guru.sfg.brewery.beer_service.services.brewing;

/**
 * Created by jt on 2019-06-23.
 */
public interface BrewingService {

    void checkForLowInventory();
}
