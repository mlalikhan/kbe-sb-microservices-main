package com.github.sfgbeerworks.sfgbrewerygateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SfgBreweryGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
